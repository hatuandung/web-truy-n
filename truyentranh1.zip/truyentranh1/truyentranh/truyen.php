<?php
	include ('controller/c_truyen.php');
     $c_truyen = new C_truyen();
     $noi_dung = $c_truyen->index();
     $tttruyen = $noi_dung['tttruyen'];
?>
<div class="col-sm-9 contain" style="border-style: none; height: 700px">
        <table border="1" style="width: 100%; text-align: center;">
	        <tr >
	        <th style="width:33%;">ID truyện</th>
	        <th >tên truyện</th>
	        <th >hình ảnh</th>
	        <th >tên tác giả</th>
	        </tr>
	        <?php
	        foreach ($tttruyen as $truyen) {
	        	?>
	        	<tr>
	        	<td><?=$truyen->idTruyen?></td>
	        	<td><?=$truyen->tenTruyen?></td>
	        	<td><img src="<?=$truyen->hinhAnh?>" alt=""  width=100px; height=120px></td>
	        	<td><?=$truyen->tenTacGia?></td>
	        	</tr>
	        	<?php
	        }
	        ?>
	        
	        
          </table>
      </div>
