<?php
     include ('controller/c_truyen.php');
     $c_truyen = new C_truyen();
     $noi_dung = $c_truyen->index();
     $nhanvien = $noi_dung['nhanvien']
?>

<table border="1" style="width: 100%; text-align: center;">
          <tr >
          <th style="width:33%;">Ten nhan vien</th>
          <th >tài khoản</th>
          <th >pass</th>
          </tr>
          <?php
               foreach ($nhanvien as $nv ) {
                    ?>
                    <tr>
                         <td><?=$nv->tennv?></td>
                         <td><?=$nv->taikhoan?></td>
                         <td><?=$nv->pass?></td>
                    </tr>
                    <?php
               }
          ?>
          </table>