<?php
include('lb/dbcon.php');
class M_truyen extends database{
		function getslide(){
			$sql="SELECT truyen.idTruyen,truyen.tenTruyen,tttruyen.tomTat 
					FROM truyen,tttruyen 
					WHERE truyen.idTruyen=tttruyen.idTruyen";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function gettheloai(){
			$sql="SELECT * FROM theloai";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function getcapnhat(){
			$sql="SELECT truyen.idTruyen, truyen.tenTruyen,tttruyen.hinhAnh,chapter.chuong,chapter.ngayDang FROM truyen INNER JOIN tttruyen ON truyen.idTruyen=tttruyen.idTruyen INNER JOIN chapter ON truyen.idTruyen=chapter.idTruyen";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function getnew(){
			$sql="SELECT truyen.idTruyen,truyen.tenTruyen,tttruyen.hinhAnh,chapter.chuong 
			FROM truyen INNER JOIN tttruyen ON truyen.idTruyen=tttruyen.idTruyen 
			INNER JOIN chapter on truyen.idTruyen=chapter.idTruyen 
			ORDER BY truyen.idTruyen DESC LIMIT 0,7";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function phobien(){
			$sql="SELECT truyen.idTruyen,truyen.tenTruyen,tttruyen.hinhAnh,tttruyen.luotXem 
				FROM truyen 
				INNER JOIN tttruyen ON truyen.idTruyen=tttruyen.idTruyen 
				ORDER BY tttruyen.luotXem DESC ";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function capnhatluotxem($luotXem){
			$qr=" UPDATE tttruyen
			SET luotXem=luotXem+1
			WHERE luotXem=$luotXem";
			mysql_query($qr);
		}
		function getTacgia(){
			$sql="SELECT tacgia.idTacGia,tacgia.tenTacGia,truyen.tenTruyen 
			FROM tacgia 
			INNER JOIN truyen ON truyen.idTruyen=tacgia.idTruyen ";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function gettttruyen(){
			$sql="SELECT truyen.idTruyen,truyen.tenTruyen,tttruyen.hinhAnh,tacgia.tenTacGia 
					FROM truyen 
					INNER JOIN tttruyen ON truyen.idTruyen=tttruyen.idTruyen 
					INNER JOIN tacgia on truyen.idTruyen=tacgia.idTruyen";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
		function getnhanvien(){
			$sql=" SELECT * FROM nhanvien";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}

		/*function get_chapter($idTruyen){
			$sql = "SELECT *  FROM chapter WHERE truyen.idTruyen = $idTruyen ";
			$this-> setQuery($sql);
			return $this->loadAllRows(array($idTruyen));
		}*/

		function get_chapter(){
			$sql = "SELECT *  FROM chapter WHERE idTruyen = '1' ";
			$this-> setQuery($sql);
			return $this->loadAllRows();
		}
	//ham lay thong tin truyen	


		/*function get_tttruyen($idTruyen){
			$sql = "SELECT truyen.idTruyen, truyen.tenTruyen,theloai.tenTheLoai,tacgia.tenTacGia, tttruyen.tomTat FROM truyen
						INNER JOIN truyentl on truyentl.idTruyen = truyen.idTruyen
						INNER JOIN tttruyen on tttruyen.idTruyen = truyen.idTruyen
						INNER JOIN tacgia on tacgia.idTruyen = truyen.idTruyen
						INNER join theloai on theloai.idTheLoai = truyentl.idTheLoai
						WHERE truyen.idTruyen = $idTruyen";
			$this->setQuery($sql);
			return $this->loadRow(array($idTruyen));
		}*/

		function get_tttruyen(){
			$sql = "SELECT truyen.idTruyen, truyen.tenTruyen,theloai.tenTheLoai,tacgia.tenTacGia, tttruyen.tomTat FROM truyen
						INNER JOIN truyentl on truyentl.idTruyen = truyen.idTruyen
						INNER JOIN tttruyen on tttruyen.idTruyen = truyen.idTruyen
						INNER JOIN tacgia on tacgia.idTruyen = truyen.idTruyen
						INNER join theloai on theloai.idTheLoai = truyentl.idTheLoai
						WHERE truyen.idTruyen= '1'";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}
	//ham lay the loai	

		function get_theloai(){
			$sql = "SELECT truyen.tenTruyen from truyen 
						INNER JOIN truyentl on truyen.idTruyen = truyentl.idTruyen 
						INNER JOIN theloai on truyentl.idTheLoai = theloai.idTheLoai 
						WHERE theloai.idTheLoai = '1' ";
			$this->setQuery($sql);
			return $this->loadAllRows();
		}

	}
?>