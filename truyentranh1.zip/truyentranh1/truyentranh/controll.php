<?php
	$id= $_GET['id'];
	if($id==1){
		require ('tacgia.php');
	}
	else if($id==2){
		require('theloai.php');
	}
	else if($id==3){
		require('truyen.php');
	}
	else if($id==4){
		require('nhanvien.php');
	}
?>