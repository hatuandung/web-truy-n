<?php
  include ('controller/c_truyen.php');
  $c_truyen = new C_truyen();
  $noi_dung = $c_truyen->index();

  $slide=$noi_dung['slide'];
  $theloai=$noi_dung['theloai'];
  $capnhat=$noi_dung['capnhat'];
  $new=$noi_dung['new'];
  $phobien=$noi_dung['phobien'];

  $noidung1 = $c_truyen->index_chapter();
  $chapter = $noidung1['chapter'];

  $noidung2 = $c_truyen->index_tttruyen();
  $tttruyen = $noidung2['tttruyen'];


?>

<!DOCTYPE html>
<html lang="vi">
<head>
  <title>truyen tranh</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="src/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    .footer{
  height:80px;
  background-color: #222;
  clear: both;
  text-align: center;
  border: 1px solid black;
  padding: 8%;
  text-align: center;
  
}
.footer a{
  color:#828282;
  margin-left: 30px;

  
}
.carousel-caption h1{
  font-size: 70px;
}
.carousel-caption {
  float:left;
  text-align: left
  ;padding-bottom:100px;
}
a {
  text-decoration: none;
}
th{
  width: 400px;
  font-size: 20px;
   padding: 5px;
}
table{
  background-color: pink;

}
</style>
</head>
<body>
<div id="wrapper">
<div id="menu">
<nav class="navbar navbar-inverse" style="margin-bottom: 0">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="truyentranh.php">Truyện tranh</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="#">đăng nhập </a></li>
      <li class="active"><a href="#">phổ biến</a></li>
      
      <li><a href="#">Diễn đàn</a></li>
      <li><a href="#">mới cập nhật</a></li>
    </ul>
    <form id="search" style="float:right;">
            <input type="search" placeholder="Search" style="margin-top: 8px">
        </form>
  </div>
</nav>
</div>

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
 <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
  <?php
      for($i=0;$i<count($slide);$i++){
        if($i==0){
          ?>
            <div class="item active">
            <img src="img/01.png" alt="" style="width: 100%; height: 400px;">
            <div class="carousel-caption">
            <h1 ><?=$slide[$i]->tenTruyen?></h1>
            <p><?=$slide[$i]->tomTat?></p>
            </div>
            </div>  
          <?php
        }
        else{
          ?>
            <div class="item">
            <img src="img/02.png" alt="Chicago" style="width: 100%; height: 400px;">
            <div class="carousel-caption">
              <h1><?=$slide[$i]->tenTruyen?></h1>
              <p><?=$slide[$i]->tomTat?></p>
            </div>
            </div>
          <?php
        }
      }
  ?>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- bar -->
<nav class="navbar navbar-default" style="text-align: center;">
  <div class="container-fluid" >
    
    <ul class="nav navbar-nav" style="margin-left: 23% ">
      <li class="active"><a href="#">Home</a></li>
      <?php
      foreach ($theloai as $tl) {
        ?>
           <li><a href="#"><?=$tl->tenTheLoai?></a></li>
        <?php
      }
      ?>
      
    </ul>
  </div>
</nav>
<div class="bar col-sm-12" style=" height: 40px">
  <img src="img/logo.png" alt="" >
</div>
<div class="col-sm-12" style="padding-left: 300px">
  <div class="col-sm-8">
    <?php
      foreach ($tttruyen as $ttt) {
        ?>
  
        <h2>Tên Truyện: <?=$ttt->tenTruyen?></h2>
        <img src="">
        <h1>Thông tin thêm</h1>
        <div class="information" style="padding-left: 30px; background-color: pink; padding-top: 20px">
          <h4>Thể loại: <?=$ttt->tenTheLoai?></h4>
          <h4>Tác giả: <?=$ttt->tenTacGia?></h4>
          <h4>Tóm tắt: <?=$ttt->tomTat?></h4>
        </div>
        <?php
      }
    ?>
  </div>
  <br>
  <div class="col-sm-8" style="clear: both">
    <h1>Danh sách các chương</h1>
    <?php
    foreach ($chapter as $ct) {
    ?>
    
    <table >
    <tr>
      <th>Chương truyện
        <li>
          <a href="<?=$ct->linkchuong?>"> <?=$ct->chuong?> 
          </a>
        </li>


      </th>
      <th>Ngày đăng
        <li>
          <?=$ct->ngayDang?>
        </li>
      </th>
    </tr>
  </table>
  <?php
  }
  ?>
  </div>
  
</div>
<div class="footer col-sm-12">
    <div class="col-sm-6" style="text-align: center;">
    <a href="#">Báo lỗi giao diện</a>
    <a href="#"> Quy định và hướng dẫn</a>
    <a href="#">Giới thiệu và cập nhật</a>
  </div>
  <p class="col-sm-6" style="color: white;">©2015-2016 (Public Beta) vnsharing.site</p>
</div>

</body>
</html>
