<?php 
include('model/m_truyen.php');
class C_truyen{
	
	public function index(){
		$m_truyen = new M_truyen();
		$slide=$m_truyen->getslide();
		$theloai=$m_truyen->gettheloai();
		$capnhat=$m_truyen->getcapnhat();
		$new=$m_truyen->getnew();
		$phobien=$m_truyen->phobien();
		$tacgia=$m_truyen->getTacgia();
		$ttTruyen=$m_truyen->gettttruyen();
		$nhanvien=$m_truyen->getnhanvien();
		return array('slide'=>$slide,'theloai'=>$theloai,'capnhat'=>$capnhat,'new'=>$new,'phobien'=>$phobien,'tacgia'=>$tacgia,'tttruyen'=>$ttTruyen,'nhanvien'=>$nhanvien);
	}

	public function index_chapter(){
		$m_chapter = new M_truyen();
		$chapter = $m_chapter->get_chapter();
		return array('chapter' =>$chapter);
	}

	/*public function index_chapter(){
		$idTruyen = $_GET['idTruyen'];
		$m_chapter = new M_truyen();
		$chapter = $m_chapter->get_chapter();
		return array('chapter' =>$chapter);
	}*/


	/*public function index_tttruyen(){
		$idTruyen = $_GET['idTruyen'];
		$m_chapter = new M_truyen();
		$tttruyen = $m_chapter->get_tttruyen('idTruyen');
		return array('tttruyen' =>$tttruyen);
	}*/
	public function index_tttruyen(){
		//$id_truyen = $_GET['idTruyen'];
		$m_chapter = new M_truyen();
		$tttruyen = $m_chapter->get_tttruyen();
		return array('tttruyen' =>$tttruyen);
	}

	/*public function index_theloai(){
		$m_chapter = new M_truyen();
		$theloai = $m_chapter->get_theloai();
		return array('theloai' =>$theloai );
	}*/
	public function index_theloai(){
		$idTruyen = $_GET['idTruyen'];
		$m_chapter = new M_truyen();
		$theloai = $m_chapter->get_theloai('idTruyen');
		return array('theloai' =>$theloai );
	}
}
?>