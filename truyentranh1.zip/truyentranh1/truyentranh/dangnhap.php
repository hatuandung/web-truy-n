<!DOCTYPE html>
<html>
<head>
	<title></title>
	  	<link rel="stylesheet" type="text/css" href="src/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<style>
			body{
				margin:auto;
	            background-image: url(img/ima.jpg);
	            background-repeat: no-repeat;
	            background-size: 100%;
			}
			.container{
				width: 500px;
				height: 400px;
				text-align: center;
				background-color: #828282;
			 	border-radius: 4px;
			 	margin:0 auto;
			 	margin-top: 150px;
			}
			.khung{
				margin-top: 150px;
			}
			input [type="text"],input [type="password"]{
				height: 45px;
				width: 300px;
				font-size: 18px;
				margin-bottom: 20px;
				background-color: #fff;
				padding-left: 30px;

			}
			form-input::before{
				content:"";
				position: absolute;
				font-size: 30px;

			}
			.btn-login{
				
				padding: 15px 25px;
				color: #fff;
				background-color: #2ecc71; 
			}
		</style>
</head>
<body>
	<div class="container" >
		<form class="khung">
			<div class="form-input">
				<span style="color:white;font-size: 20px;">Username: </span>
				<input type="text" name="username" placeholder="đăng nhập" style="height: 40px; width: 250px;-moz-border-radius: 10px;
-webkit-border-radius: 10px; margin-left:10px;">
			</div>
			<div class="form-input">
				<span style="color:white;font-size: 20px;">Password:  </span>
				<input type="password" name="password"  placeholder="mật khẩu" style="height: 40px; width: 250px;-moz-border-radius: 10px;
-webkit-border-radius: 10px; margin-left:10px;">
			</div>
			<input type="submit" name="submit" value="LOGIN" class="btl-login" style="margin:10px; width: 80px;height: 30px;">
		</form>
	</div>
</body>
</html>