<?php
	include ('controller/c_truyen.php');
 	$c_truyen = new C_truyen();
  	$noi_dung = $c_truyen->index();
  	$theloai=$noi_dung['theloai'];
?>
        <table border="1" style="width: 100%; text-align: center;">
	        <tr >
	        <th style="width:33%;">ID thể loại</th>
	        <th >tên thể loại</th>
	        
	        </tr>
	        <?php
	        	foreach ($theloai as $TL) {
	        		?>
	        			<tr>
	        			<td><?=$TL->idTheLoai?></td>
	        			<td><?=$TL->tenTheLoai?></td>
	        			</tr>
	        		<?php
	        	}
	        ?>
	        

          </table>
