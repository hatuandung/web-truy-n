<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" type="text/css" href="..\src\bootstrap-3.1.1-dist\css\bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="..\src\bootstrap-3.1.1-dist\css\bootstrap-theme.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style >
    .btn{
      width: 100%;
      border: 2px solid;
      font-size: 15px;
      background-color:rgb(19, 4, 37);
      color: white;
      border: none;
      text-align: left;
      padding-left: 30px;
    }
    .btn:hover{
      background-color: rgb(33, 3, 62);
      color: rgb(255, 0, 0);
    }
    td{

    }
  </style>
</head>

<body>
  <div class="col-sm-12" style="padding: 0px">
    <div class="col-sm-12 top_backend" style="padding-bottom: 0;background-color: rgb(4, 3, 46); color: white;padding: 4px; padding-right:10%">
      <img src="" alt="">
      <span class="dropdown" style="float: right">
        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">setting
  <span class="caret"></span></button>
      <ul class="dropdown-menu">
        <li><a href="#">Thong tin tai khoan</a></li>
        <li><a href="#">Ðoi mat khau</a></li>
        <li><a href="#">Ðang xuat</a></li>
      </ul>
      </span>
      <span style="float: right; padding-top: 5px; margin-right: 12px"><p>Huyen</p></span>
    </div>
    <div class="col-sm-3 menuleft list-group" style="height:700px ;margin-top: 0; padding: 0; background-color: rgb(19, 4, 37);">
        <h1 class="list-group-item "style="margin-top: 0px; border: none; text-align: center;background-color:green ;color: white">Quan ly</h1>
        <input type="text" name="" value="" placeholder="Tim kiem ..." style="margin-top: 10px; margin-left: 15px; border-radius: 10px 10px 10px 10px; padding-left:5px ">
        <button class="list-group-item btn" type="button" name="button" onclick="loadManager(4)">Nhan vien</button>
        <button class="list-group-item btn" type="button" name="button" onclick="loadManager(1)" >Tac gia</button>
        <button class="list-group-item btn" type="button" name="button" onclick="loadManager(3)">Truyen</button>
        <button class="list-group-item btn" type="button" name="button" onclick="loadManager(2)">The loai</button>
     </div>
      <div class="col-sm-9 contain" style="border-style: none; height: 700px">
        
      </div>
    </div>
    <script type="text/javascript" src="..\src\bootstrap-3.1.1-dist\js\bootstrap.js"></script>
    <script type="text/javascript" src="..\src\jquery-3.3.1.min.js"></script>
    <script>

      function loadManager(id) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          $('.contain').html(this.responseText);
            };
        };
      xhttp.open("GET",'controll.php?id=' + id, true);
      xhttp.send();
}
    </script>
</body>

</html>