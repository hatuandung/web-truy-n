<?php
     include ('controller/c_truyen.php');
     $c_truyen = new C_truyen();
     $noi_dung = $c_truyen->index();
     $tacgia=$noi_dung['tacgia'];
          
?>

        <table border="1" style="width: 100%; text-align: center;">
          <tr >
          <th style="width:33%;">Ten tác giả</th>
          <th >id tác giả</th>
          <th >id truyện</th>
          </tr>
          <?php
               foreach ($tacgia as $tg) {
                    ?>
                         <tr>
                         <td><?=$tg->idTacGia?></td>
                         <td><?=$tg->tenTacGia?></td>
                         <td><?=$tg->tenTruyen?></td>
                         </tr>
                    <?php
               }
          ?>
          
          
          </table>
