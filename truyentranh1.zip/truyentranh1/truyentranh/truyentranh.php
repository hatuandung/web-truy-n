<?php
  include ('controller/c_truyen.php');
  $c_truyen = new C_truyen();
  $noi_dung = $c_truyen->index();
  $slide=$noi_dung['slide'];
  $theloai=$noi_dung['theloai'];
  $capnhat=$noi_dung['capnhat'];
  $new=$noi_dung['new'];
  $phobien=$noi_dung['phobien'];

    // print_r($phobien);
?>


<!DOCTYPE html>
<html lang="vi">
<head>
  <title>truyen tranh</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="src/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    .footer{
  height:80px;
  background-color: #222;
  clear: both;
  text-align: center;
  border: 1px solid black;
  padding: 8%;
  text-align: center;
  
}
.footer a{
  color:#828282;
  margin-left: 30px;

  
}
.carousel-caption h1{
  font-size: 70px;
}
.carousel-caption {
  float:left;
  text-align: left
  ;padding-bottom:100px;
}
a {
  text-decoration: none;
}
</style>
</head>
<body>
<div id="wrapper">
<div id="menu">
<nav class="navbar navbar-inverse" style="margin-bottom: 0">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Truyện tranh</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="#">Đăng nhập </a></li>
      <li class="active"><a href="#">Phổ biến</a></li>
      
      <li><a href="#">Diễn đàn</a></li>
      <li><a href="#">Mới cập nhật</a></li>
    </ul>
    <form id="search" style="float:right;">
            <input type="search"  id="txtSearch" placeholder="Search" style="margin-top: 8px">
            <button type="button" id="btnSearch" class="btn btn-default">Tìm kiếm</button>
        </form>
  </div>
</nav>
</div>

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
 <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
  <?php
      for($i=0;$i<count($slide);$i++){
        if($i==0){
          ?>
            <div class="item active">
            <img src="img/01.png" alt="" style="width: 100%; height: 400px;">
            <div class="carousel-caption">
            <h1 ><?=$slide[$i]->tenTruyen?></h1>
            <p><?=$slide[$i]->tomTat?></p>
            </div>
            </div>  
          <?php
        }
        else{
          ?>
            <div class="item">
            <img src="img/02.png" alt="Chicago" style="width: 100%; height: 400px;">
            <div class="carousel-caption">
              <h1><?=$slide[$i]->tenTruyen?></h1>
              <p><?=$slide[$i]->tomTat?></p>
            </div>
            </div>
          <?php
        }
      }
  ?>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- bar -->
<nav class="navbar navbar-default" style="text-align: center;">
  <div class="container-fluid" >
    
    <ul class="nav navbar-nav" style="margin-left: 23% ">
      <li class="active"><a href="#">Home</a></li>
      <?php
      foreach ($theloai as $tl) {
        ?>
           <li><a href="#"><?=$tl->tenTheLoai?></a></li>
        <?php
      }
      ?>
      
    </ul>
  </div>
</nav>
<div class="bar col-sm-12" style=" height: 40px">
  <img src="img/logo.png" alt="" >
</div>
<div id="content">
  <div class="newupdate">
    <div class="inner_title_wrap">
        <div class="inner_title p_r">
          <a href="#" style="color: black;">MỚI CẬP NHẬT</a>
        </div>
          <a class="series_showall" href="#"> Xem tất cả</a>
      <div class="inner_des p_r">Các bộ manga mới được cập nhật chương mới</div>
      </div>
      <?php
        foreach ($capnhat as $ct) {
          ?>
            <div class="new" >
            <div class="new-update" style="width: 250px; margin-left: 30px;">
            <img src="<?=$ct->hinhAnh?>" width="100px" height="120px" >
            <span class="ten-truyen"><a href="thongtin.php?idTruyen=<?=$ct->idTruyen?>" class="manga-update-name"><?=$ct->tenTruyen?></a></span>
            <br>
            <a href="#" class="manga-update-chuong">số chương<?=$ct->chuong?></a>
            <br><span class="manga-update-date"><?=$ct->ngayDang?></span><br>
            <br>
            </div>
          <?php
        }
      ?>
      
        
    </div>
  <div class="newupdate">

    <div class="inner_title_wrap">
        <div class="inner_title p_r">
          <a href="#" style="color:black;">MỚI RA MẮT</a>
        </div>
          <a class="series_showall" href="#"> Xem tất cả</a>
      <div class="inner_des p_r">Các bộ truyện mới ra mắt trên Cổng Truyện Dịch.</div>
      </div>
      <div class="new" >
            <?php
            foreach ($new as $nw ) {
              ?>
                  <div class="new-update" style="width: 250px; margin-left: 30px;">
                  <img src="<?=$nw->hinhAnh?>" width="100px" height="120px" >
                  <span class="ten-truyen"><a href="#" class="manga-update-name"><?=$nw->tenTruyen?></a></span>
                  <br>
                  <a href="#" class="manga-update-chuong">số chương<?=$nw->chuong?> </a>
                  
                  <br>
                  </div>
              <?php
            }
            ?>
        
        <!--  -->
      </div>
</div>
<div class="newupdate">
    <div class="inner_title_wrap">
        <div class="inner_title p_r">
          <a href="#" style="color:black;">PHỔ BIẾN</a>
        </div>
          <a class="series_showall" href="#"> Xem tất cả</a>
      <div class="inner_des p_r">Các bộ truyện đang được xem nhiều nhất trên Cổng Truyện Dịch.</div>
      </div>
      <div class="new" >
        <?php
            foreach ($phobien as $pb) {
              ?>
                <div class="new-update" style="width: 250px; margin-left: 30px;">
                <img src="<?=$pb->hinhAnh?>" width="100px" height="120px" >
                <span class="ten-truyen"><a href="#" class="manga-update-name"><?=$pb->tenTruyen?></a></span>
                <br>
                
                <br><span class="manga-update-date">lượt:<?=$pb->luotXem?></span><br>
                <br>
                </div>
              <?php
            }
        ?>
    </div>
</div>
  </div>
<div class="footer col-sm-12">
    <div class="col-sm-8" style="text-align: center;">
    <a href="#">Báo lỗi giao diện</a>
    <a href="#"> Quy định và hướng dẫn</a>
    <a href="#">Giới thiệu và cập nhật</a>
  </div>
  <p class="col-sm-4" style="color: white;">©2015-2016 (Public Beta) vnsharing.site</p>
</div>
<script>
  
</script>
</body>
</html>
