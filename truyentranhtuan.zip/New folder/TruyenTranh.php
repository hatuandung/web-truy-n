<!DOCTYPE html>
<html>
<head>
  <title>
    
  </title>
  <link rel="stylesheet" type="text/css" href="TruyenTranh.css">
  <link rel="stylesheet" type="text/css" href="src\bootstrap-3.1.1-dist\css\bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="src\bootstrap-3.1.1-dist\css\bootstrap-theme.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
</head>
<body>
  <div class="container-fluid">
    <div id ="header">
      <button>
        <h2>
          COMIC
        </h1>
      </button>
    </div>
    <div id ="search">
      
    </div>
    <div class=" col-sm-12">
      
    </div>
    <div class="col-sm-1">
      
    </div>
    <div class="col-sm-10">
      <div class="col-sm-8" style="background-color: green; padding: 10px;">
        
        <div class = "info-comic" style = "background-color: black; padding: 10px;height: 200">
          <img src="http://truyentranhtuan.com/wp-content/uploads/2017/03/bia-Inno.png" style="float: left; margin-right: 30px">  
        <h2> TEN TRUYEN </h2>
          <div>
            <p> Tên truyện : </p>
            <p> Tác giả : 
              <a href="#"></a>
            </p>
            <p> Thể loại : 
              <a href="#"></a>
            </p>
            <p> Số chương : </p>
          </div>
          </div>


          <div class = "comic-chapter" style = "clear:both">
            <span id="chapter-header">Tên Chương</span>
            <span id="date-header">Ngày Đăng</span>
            
          </div>






    </div>
      
      <div class="col-sm-3" style="background-color: blue">
        ads
      </div>
    </div>
    <div class="col-sm-1">
      
    </div>
    
  </div>
</body>
</html>