<div class="footer col-sm-12">
  &copy; Bản quyền thuộc về tập đoàn nhảm nhỉ
</div>
