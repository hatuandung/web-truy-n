<?php
	require('config.php')
	$link = mysqli_connect($host,$user,$pass,$db);
	if(!$link){
		echo'Ket noi khong thanh cong','-'mysqli_connect_error();

	}else{
		mysqli_set_charset($link,'UTF8');
		$sql = "SELECT chuong FROM chapter";
		$result = mysqli_query($link,$sql);
		if(mysqli_num_rows($result)>0){
			while ($row = mysqli_fetch_assoc($result)) {
				$hienthi='<li value="'.$row['id'].'"><a href="">&raquo; '.$row[''].'</a></li>';
			echo $hienthi;
		}
		
	}else{
		echo 'Ko ton tai ban ghi nao';
	}
	}

	mysqli_close($link);"'
			}
		}
	}




?>