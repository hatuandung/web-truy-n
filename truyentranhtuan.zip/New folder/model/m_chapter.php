<?php
include('database.php');
class M_chapter extends database{
	//Lay du lieu tu database
	function get_chapter(){
		$sql = "SELECT * FROM chapter where idTruyen ='1'";
		$this-> setQuery($sql);
		return $this->loadAllRows();
	}

}
?>