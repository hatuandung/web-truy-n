<?php
include('model/m_chapter.php');
class C_chapter{
	public function index(){
		$m_chapter = new M_chapter();
		$chapter = $m_chapter->get_chapter();
		return array('chapter' =>$chapter);
	}
}
?>