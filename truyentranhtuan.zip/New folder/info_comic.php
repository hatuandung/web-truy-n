<?php
  include('controller\c_chapter.php');
  $c_chapter = new C_chapter();
  $noi_dung = $c_chapter->index();
  $chapter = $noi_dung['chapter'];
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" type="text/css" href="src\bootstrap-3.1.1-dist\css\bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="src\bootstrap-3.1.1-dist\css\bootstrap-theme.min.css">
  <link rel="stylesheet" href="src/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="icon" href="img\icon.jpg">
</head>
<style>
  table tr th{
    padding-left: 100px;
    padding-right: 40px;
  }
</style>
<body>
  <div class="container-fluid" style="padding: 0px">
    <div class="col-sm-12">
      <div id ="header" style="border-style: double;">
        <button>
          <h3>COMIC</h3>
        </button>
      </div>
      <div id = "search" style="border-style:double;">
        <p>adasda</p>
      </div>
    </div>
    <div class="col-sm-1">

    </div>
    <div class="col-sm-10">
      <div class="col-sm-8">
        <div class="col-sm-12" style="padding-top: 10px;border-style: double">
          <span style="float: left; width: 30%"><img src="http://truyentranhtuan.com/wp-content/uploads/2017/03/bia-Inno.png" alt="#"></span>
            <span class="info" style="float: left; width: 60%">
              <h2>Tên Truyện</h2>
              <p>Tác giả:
                  <a href="#"></a> 
              </p>
              <p>Thể loại:
                  <a href="#"></a> 
              </p>
              <p>Số chương:
                  <a href="#"></a>
              </p>
              <p>Vào thế kỉ XVII, tìm kiếm “tự do và bình đẳng”, sự kiện đã trở thành
                khởi đầu của xã hội Pháp hiện đại, cuộc khởi nghĩa của nước Pháp bắt đầu.
                Henry Charles Sanson, người khởi xướng trong bóng tối. Ông thuộc thế hệ thứ tư c
                ủa gia đình Sanson, Đao phủ của Paris hay còn gọi là “Monsieur de Paris”
                (Quý ngài Paris) Đây là câu chuyện về
                người đàn ông đó, người đao phủ đã chém đầu vua Louis XVI</p>
            </span>
            <br><br>
        </div>
        <div class="col-sm-12" style="border-style: double">
          <table>
            <tr>
              <th>Tên chương</th>
            </tr>
            <?php
                foreach ($chapter as $ct) {
                    ?>
                    <li class = "chapter1">
                      <a > 
                        <a href="<?=$ct->linkChuong?>">
                        <?=$ct->chuong?>  
                        </a>
                      </a>
                    </li>
                    <?php
                }
             ?>
          </table>
        </div>
      </div>

      <div class="col-sm-4" style="border-style: double;">
        <h2>Truyện cùng thể loại</h2>

      </div>

    </div>
    <div class="col-sm-1">

    </div>

  </div>
</body>

</html>